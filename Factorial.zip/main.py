def fact_rec(n):
  if n==0 or n==1:
    return 1
  else:
    return n*fact_rec(n-1)

nuber = int(input("Enter a value : "))
res = fact_rec(nuber)

print("The factorial of {} is {}.".format(nuber,res))